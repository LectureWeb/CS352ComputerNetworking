#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>

// Name:
// netID:
// RUID:
// your code for time() goes here
