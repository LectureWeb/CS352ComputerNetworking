
/* SERVIVE_PORT defines the default port number for this service 
 * replace the number with a unique number > 1024
 * a reasonable number may be obtained from, say, four
 * digits of your id + 1024
 */

#define SERVICE_PORT	21234	/* hard-coded port number */
