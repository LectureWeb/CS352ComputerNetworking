import java.net.*;

public class wait {
	public static void main(String args[]) throws Exception {
		ServerSocket svc = new ServerSocket(12345, 5);	// listen on port 12345

		Socket conn = svc.accept();	// get a connection
	}
}
