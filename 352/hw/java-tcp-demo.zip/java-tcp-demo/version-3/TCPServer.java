import java.io.*;
import java.net.*;

public class TCPServer {
	public static void main(String args[]) throws Exception {
		String line;
		ServerSocket svc = new ServerSocket(12345, 5);	// listen on port 12345

		for (;;) {
			Socket conn = svc.accept();	// get a connection from a client
			System.out.println("got a new connection");

			BufferedReader fromClient = new BufferedReader(new InputStreamReader(conn.getInputStream()));
			DataOutputStream toClient = new DataOutputStream(conn.getOutputStream());

			while ((line = fromClient.readLine()) != null) {	// while there's data from the client
				System.out.println("got line \"" + line + "\"");

				String result = line.length() + ": " + line.toUpperCase() + '\n';	// do the work

				toClient.writeBytes(result);	// send the result

			}
			System.out.println("closing the connection\n");
			conn.close();		// close connection
		}
	}
}
